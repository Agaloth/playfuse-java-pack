#version 150

#moj_import <minecraft:light.glsl>
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV1;
in ivec2 UV2;
in vec3 Normal;

uniform sampler2D Sampler1;
uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec4 lightMapColor;
out vec4 overlayColor;
out vec2 texCoord0;

flat out vec4 tint;
flat out vec3 vNormal;

flat out vec4 texel;

// 26.1: UI items now receive a 1x1 white lightmap instead of the full 16x16
// map. Clamp the fetch coordinate to valid texture bounds so both cases work.
vec4 sampleLightmap(ivec2 uv) {
    ivec2 size = textureSize(Sampler2, 0);
    return texelFetch(Sampler2, min(uv / 16, size - 1), 0);
}

void main(){
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    #ifdef NO_CARDINAL_LIGHTING
    vertexColor = Color;
    #else
    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color);
    #endif
    lightMapColor = sampleLightmap(UV2);  // 26.1: safe for 1x1 UI lightmap
    overlayColor = texelFetch(Sampler1, UV1, 0);

    texCoord0 = UV0;
    #ifdef APPLY_TEXTURE_MATRIX
    texCoord0 = (TextureMat * vec4(UV0, 0.0, 1.0)).xy;
    #endif

    vNormal = Normal;
    tint = Color;
    texel = sampleLightmap(UV2);          // 26.1: safe for 1x1 UI lightmap
}
